import hangmanRun
import asciiArt
'''💃 Hangman 
A virtual game of the game hangman.
By: Fauzia Kabajemi
Created: June 2, 2022
Last Edited: June 18 2022'''



asciiArt.title()

#score_dict or SD = the dictonary of the leaderboard
score_dict = {}

choice = " "

#A while loop to call all the functions in the other files depending on the users choice in the menu of the game.
while choice.lower() != "x":
    SD = {}  #This is an empty dictionary for the leaderboard. SD = score dictionary

    word = hangmanRun.pickingWord() # picks a different word each loop this is to ensure the word is different almost all the time when the user plays the game. 
    choice = hangmanRun.menu()             
    
    if choice.lower() == "a":
        username = input("Name: ")
        hangmanRun.clearScreen()
        score = hangmanRun.gameRuns(word)

         
        scoreDict = hangmanRun.leaderboard_dict(SD, username, score,)

        #to put the items of the dictionary in the text file. 
        hangmanRun.leaderboard(scoreDict)

    if choice.lower() == "b":
        hangmanRun.clearScreen()
        hangmanRun.showLeaderboard()
        
    
    if choice.lower() == "c":
        hangmanRun.clearScreen()
        hangmanRun.rules()

    