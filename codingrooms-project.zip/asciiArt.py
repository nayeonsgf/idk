'''💃 Hangman Ascii Art 
This file holds all the ASCII art in the program.
By: Fauzia Kabajemi
Created: June 11, 2022
Last Edited: June 18 2022'''

'''Function to show the game title'''
def title():
    print('''  o         o           o           o          o        o__ __o       o          o           o           o          o  
 <|>       <|>         <|>         <|\        <|>      /v     v\     <|\        /|>         <|>         <|\        <|> 
 < >       < >         / \         / \\o      / \     />       <\    / \\o    o// \         / \         / \\o      / \ 
  |         |        o/   \o       \o/ v\     \o/   o/               \o/ v\  /v \o/       o/   \o       \o/ v\     \o/ 
  o__/_ _\__o       <|__ __|>       |   <\     |   <|       _\__o__   |   <\/>   |       <|__ __|>       |   <\     |  
  |         |       /       \      / \    \o  / \   \\          |    / \        / \      /       \      / \    \o  / \ 
 <o>       <o>    o/         \o    \o/     v\ \o/     \         /    \o/        \o/    o/         \o    \o/     v\ \o/ 
  |         |    /v           v\    |       <\ |       o       o      |          |    /v           v\    |       <\ |  
 / \       / \  />             <\  / \        < \      <\__ __/>     / \        / \  />             <\  / \        < \ ''')




'''Function to show the starting image of the game'''
def start():
    print('''
  +---+
  |   |
      |
      |
      |
      |
=========''')

'''Function add the head of the stick man'''
def head():
    print('''
  +---+
  |   |
  O   |
      |
      |
      |
=========''')

'''Function to show the body of the stick man'''
def body():
    print('''
  +---+
  |   |
  O   |
  |   |
      |
      |
=========''')

'''Function to show the left arm of the stick man'''
def leftArm():
    print('''
  +---+
  |   |
  O   |
 /|   |
      |
      |
=========''')

'''Function to show the right arm of the stickman'''
def rightArm():
    print('''
  +---+
  |   |
  O   |
 /|\  |
      |
      |
=========''')

'''Function to show the left leg of the stickman'''
def leftLeg():
    print('''
  +---+
  |   |
  O   |
 /|\  |
 /    |
      |
=========''')

'''Function to show the right leg of the stickman'''
def rightLeg():
    print('''
  +---+
  |   |
  O   |
 /|\  |
 / \  |
      |
=========''')


'''Function to show the Leaderboard title'''
def leaderboardTitle():
    print("\n\n")
    print('''  _      ___     _     ___    ___   ___   ___    ___      _     ___   ___  
 | |    | __|   /_\   |   \  | __| | _ \ | _ )  / _ \    /_\   | _ \ |   \ 
 | |__  | _|   / _ \  | |) | | _|  |   / | _ \ | (_) |  / _ \  |   / | |) |
 |____| |___| /_/ \_\ |___/  |___| |_|_\ |___/  \___/  /_/ \_\ |_|_\ |___/ ''')


'''Function to show the title for the instructions'''
def rulesTitle():
    print("\n\n")
    print('''  _  _    ___   __      __     _____    ___        ___   _        _    __   __
 | || |  / _ \  \ \    / /    |_   _|  / _ \      | _ \ | |      /_\   \ \ / /
 | __ | | (_) |  \ \/\/ /       | |   | (_) |     |  _/ | |__   / _ \   \ V / 
 |_||_|  \___/    \_/\_/        |_|    \___/      |_|   |____| /_/ \_\   |_|''')

   