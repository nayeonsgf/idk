
import random
import asciiArt

'''💃 Hangman Game Runs
This file defines most of the functions that run the program such as the function to run the actual game, leaderboard and games rules. 
By: Fauzia Kabajemi
Created: June 2, 2022
Last Edited: June 18 2022'''


#-------------------------------------------------------------------------------------------------------------------------------------------------------
'''Function to create a series of dotted lines'''
def dottedLines():
    print("\n--------------------------------------------------------------------------------------------------------------------------------")
#-------------------------------------------------------------------------------------------------------------------------------------------------------



#-------------------------------------------------------------------------------------------------------------------------------------------------------
'''Function to add large amount of space'''
def clearScreen():
    print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")
#-------------------------------------------------------------------------------------------------------------------------------------------------------



#-------------------------------------------------------------------------------------------------------------------------------------------------------
'''Function to add space'''
def space():
    print("\n\n")
#-------------------------------------------------------------------------------------------------------------------------------------------------------



#-------------------------------------------------------------------------------------------------------------------------------------------------------
'''Function to pick a random word in the list of words contained in the word file'''
def pickingWord():
    fileContent = []  #creates an empty list to be added to later 
    wordsFile = open("words.txt", "r")   
    num = random.randint(0,99)  #randomizes 100 words so even I don't know what word will be picked 
    for line in wordsFile:
        fileContent.append(line.strip())

    wordPicked = (fileContent[num]) #assigns the word chosen from the randomized list above to be used in the game 
    return wordPicked
#-------------------------------------------------------------------------------------------------------------------------------------------------------




#-------------------------------------------------------------------------------------------------------------------------------------------------------
'''Function to print the parts of the stick man everytime a user gets the letter or word wrong'''
def hangman(time):
    if time == 120:
        asciiArt.start()
#each time a user looses points a body part is added. 120/20 = 6 that means if the user gets it wrong 6 times game over. 
    if time == 100:
        asciiArt.head()   #the names of the function indicates what body part is added

    if time == 80:
        asciiArt.body()

    if time == 60:
        asciiArt.leftArm()

    if time == 40:
        asciiArt.rightArm()  

    if time == 20:
        asciiArt.leftLeg()   

    if time == 0:
        asciiArt.rightLeg()  
#-------------------------------------------------------------------------------------------------------------------------------------------------------




#-------------------------------------------------------------------------------------------------------------------------------------------------------
'''Function to print out the menu options'''
def menu():
    print('''
________________________________________

-> Start        (A)
-> Leaderboard  (B)
-> How To Play  (C) 
-> Exit         (X)
________________________________________''')

    choose = input("\nChoice: ")
    return choose
#-------------------------------------------------------------------------------------------------------------------------------------------------------




    
#---------------------------------------------------------------------------------------------------------------------------------------------------------
'''This function takes the mystery word, and the user tries to guess the letters of that word or the whole word. Each time the user gets the letter or word wrong a body part of a stickman will be shown to eventually create a full stickman, which ends the game and the user looses. If the user makes the correct guesses/guess before that happens, the game ends and the user wins.'''

def gameRuns(word_): 
    space()
    # dashes to indicate how many letters they are in the word 
    dashes = "_ "*len(word_)
    wordlist = dashes.split()  

    # a list of each letter in the word chosen
    completedWord = (list(word_))

    # points that every user starts with 
    points = 120
    
    # a list of every wrong guess the user inputs 
    wrongGuesses = []

    hangman(points) 
    print("\nYour points:",points)
    print("\n",dashes)

    print("\nWrong guesses:")

    while not(completedWord == wordlist or points == 0):
        space()
        dottedLines()  

        space()
        guess = input("guess the letter or word: ")
        
        # replaces every dash with a CORRECT guess 
        for i in range(len(word_)):
            if guess.lower() == word_[i]:
                wordlist[i] = guess.lower()

        # The user losses 20 points for every worng guess they make 
        if not(guess.lower() in wordlist or guess.lower() == word_) :
            points -= 20
            #The program lets the user know each time 
            space()
            print("-20 points\nYour points:",points)
            #The wrong guesses are put into a list to be printed out later.
            wrongGuesses.append(guess)


        hangman(points)
        
        #if the user inputs the full word and gets it right game ends 
        if guess.lower() == word_:
            break 
        
            
        print("\n") 

        #prints the elements from wordlist in this case the right inputs and/or dashes in a single line. 
        for ltr in wordlist:
            print(ltr, end =" ")
            
        print("\nWrong guesses:")

        #prints all the wrong guesses 
        for i in wrongGuesses:
            print(i.lower(), end =", ")

         
    dottedLines()  
     
    #If the user gets the word right with enough points
    if points > 0 :
        space()
        print("Congratulations YOU WON!!!")
        space()
        print("-20 points\nYour points:",points)
    else:
        space()
        print("YOU LOST LOL :D")

    space()
    print("GAME OVER")

    print("\nThe word was:", word_)
    dottedLines()
    return points        
#-------------------------------------------------------------------------------------------------------------------------------------------------------





#-------------------------------------------------------------------------------------------------------------------------------------------------------    
''''Function to print out the instructions of the game.'''
def rules():
    asciiArt.rulesTitle()
    dottedLines()
    
    print('''

Guess all the letters in the mystery word (the number of dashes indicates how many letters they are) or the full word. 
For every letter or word you get wrong a part of the stickman will show.
The letters that are not included in the word will be shown after you guessed them.

Your objective: Guess the word/phrase before your man gets hung!''')
    dottedLines()
#-------------------------------------------------------------------------------------------------------------------------------------------------------




#-------------------------------------------------------------------------------------------------------------------------------------------------------
''' Function to add to the dictionary of scores the names as the keys and scores as values.'''
def leaderboard_dict(score_dict,name,points):
    score_dict[name] = points
    return score_dict
#-------------------------------------------------------------------------------------------------------------------------------------------------------



#-------------------------------------------------------------------------------------------------------------------------------------------------------
'''Function to write the score and names from the dictionary to the text file scores.txt. ex Fauzia: 80 '''
def leaderboard(score_dict):    # the empty score dictionary is found in the main file 
    scoreFile = open("scores.txt","a")

    for name, points in score_dict.items():
        #writes each players name and score accordingly
        points = str(points)
        scoreFile.write(name)
        scoreFile.write(" : ")
        scoreFile.write(points)
        scoreFile.write("\n")
#-------------------------------------------------------------------------------------------------------------------------------------------------------




#-------------------------------------------------------------------------------------------------------------------------------------------------------
'''Function to show the leaderboard written in scores.txt.'''
def showLeaderboard():
    asciiArt.leaderboardTitle()
    dottedLines()
    
    scoreFile_content = [] # empty score list 
    scoreFile = open("scores.txt","r") 
    #here it adds everything written from the text file, scores.txt to the empty list. Each line is an element.
    for line in scoreFile:
        scoreFile_content.append(line.strip())
    
    #prints that list accordingly 
    for score in scoreFile_content:
        print(score)
    dottedLines()
#-------------------------------------------------------------------------------------------------------------------------------------------------------
